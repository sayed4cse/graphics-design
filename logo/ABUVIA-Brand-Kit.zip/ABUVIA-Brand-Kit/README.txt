ABUVIA - OFFICIAL BRAND KIT
===========================
Logo: A + V monogram (A = peak, V = "via", the way) with custom geometric wordmark.

00_ABUVIA-Brand-Guide.pdf   Complete brand guide in one PDF (logos, colors, usage, license)

FOLDERS
svg/            Master vector files (use for print, signage, web, any scaling)
pdf/            Vector PDFs for printers and designers
png/            Transparent PNGs in several sizes
jpg-white-bg/   JPG on white, for places that do not accept transparency
favicon/        favicon.ico, 16/32 px, apple-touch-icon, android icons

VERSIONS (file names)
mark        A+V symbol only
stacked     symbol above the ABUVIA name
horizontal  symbol left, name right
circle      round badge (profile pictures, social media)
icon        square app icon (full-bleed)

COLORWAYS
color    for light backgrounds
reverse  for dark backgrounds (white A and text, green V)
black    one-color black
white    one-color white

COLORS
Ink Black  #0E1419
Emerald    #10A56F  (gradient #067A52 -> #34D399)
White      #FFFFFF

USAGE
- Keep clear space around the logo equal to the width of the A's leg.
- Do not stretch, rotate, recolor or add effects.
- Do not use the color version on dark backgrounds; use reverse.
- Minimum size: symbol 24 px / 8 mm, stacked logo 80 px / 25 mm wide.

LICENSE
See LICENSE.txt / LICENSE.pdf for the ABUVIA Logo and Brand Assets License.
